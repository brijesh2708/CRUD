insert into student
values(10001,'Ranga', 'E','1234');

insert into student
values(10002,'Ravi', 'A','1234');