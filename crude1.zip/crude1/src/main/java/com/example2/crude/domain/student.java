package com.example2.crude.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity

public class student {

	@Id
	//@GeneratedValue
	private Long id;
	private String name;
	private String sec;
	private String rollNo;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSec() {
		return sec;
	}
	public void setSec(String sec) {
		this.sec = sec;
	}
	public String getRollNo() {
		return rollNo;
	}
	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}
	public student(Long id, String name, String sec, String rollNo) {
		super();
		this.id = id;
		this.name = name;
		this.sec = sec;
		this.rollNo = rollNo;
	}
	public student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
