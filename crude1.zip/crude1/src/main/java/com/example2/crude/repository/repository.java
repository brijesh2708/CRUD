package com.example2.crude.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example2.crude.domain.student;
public interface repository extends JpaRepository<student , Long>{
	

}
